import AWS from 'aws-sdk';

const ec2 = new AWS.EC2();

export const handler = async (event) => {
  try {
    const params = {
      InstanceIds: [process.env.INSTANCE_ID],
    };
    
    const data = await ec2.startInstances(params).promise();
    const result = "Instance started";

    const response = {
      statusCode: 200,
      body: JSON.stringify({ message: result }),
    };
    return response;
  } catch (error) {
    console.error(error);
    const response = {
      statusCode: 500,
      body: JSON.stringify({ message: "Error during script" }),
    };
    return response;
  }
};

