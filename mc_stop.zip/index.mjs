import AWS from 'aws-sdk';

const ec2 = new AWS.EC2();

export const handler = async (event) => {
  try {
    const params = {
      InstanceIds: [process.env.INSTANCE_ID],
    };

    const data = await ec2.describeInstances(params).promise();
    const instance = data.Reservations[0].Instances[0];

    if (instance.State.Name !== "stopped") {
      const launchTime = new Date(instance.LaunchTime);
      const today = new Date();
      const hoursRunning = (today - launchTime) / 3600000;

      if (hoursRunning > process.env.MAX_HOURS) {
        console.log("Stopping the instance...");
        await ec2.stopInstances(params).promise();
        return {
          statusCode: 200,
          body: JSON.stringify({ message: "Instance stopped" }),
        };
      } else {
        return {
          statusCode: 200,
          body: JSON.stringify({ message: "Instance running" }),
        };
      }
    } else {
      return {
        statusCode: 200,
        body: JSON.stringify({ message: "Instance not running" }),
      };
    }
  } catch (error) {
    console.error(error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: "Error during script" }),
    };
  }
};

